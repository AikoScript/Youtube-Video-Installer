--Important Before Run The Program--

1
Username :Aiko
Password :123
2 All video u install are in the file "VIDEO"
3 If the script "Not respond" its normal just wait
4 Do not change the name of the “VIDEO” file so as not to interfere with the pogram and render it unusable.
5 The script is 100% safe i not take ur information or other its just python scripte which i change into .exe if u are scary i can show the script.
6 If u have some problem with the script contact me in discord :262646



BUG : 1080p doesn't work pls use 720p //
